// export function filterPeople() {
//     document.addEventListener("turbo:load", () => {
//         const searchInput = document.querySelector('.input-search');
//         const listItems = document.querySelectorAll('.list-item');
//         const noResultsMessage = document.querySelector('.list-message');
        
//         if (searchInput) {
//             searchInput.addEventListener('input', (e) => {
//                 const searchTerm = e.target.value.toLowerCase();
//                 let itemsFound = 0;
            
//                 listItems.forEach((item) => {
//                 const name = item.querySelector('.name').textContent.toLowerCase();
            
//                 if (name.includes(searchTerm)) {
//                     item.style.display = 'flex';
//                     itemsFound++;
//                 } else {
//                     item.style.display = 'none';
//                 }
//                 });
            
//                 if (itemsFound === 0) {
//                 noResultsMessage.style.display = 'flex';
//                 } else {
//                 noResultsMessage.style.display = 'none';
//                 }
//             });
//         }
//     });
//   }

  
  
  
  
  
  ;
